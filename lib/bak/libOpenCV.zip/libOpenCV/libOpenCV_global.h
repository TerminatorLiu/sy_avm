#ifndef LIBOPENCV_GLOBAL_H
#define LIBOPENCV_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(LIBOPENCV_LIBRARY)
#  define LIBOPENCV_EXPORT Q_DECL_EXPORT
#else
#  define LIBOPENCV_EXPORT Q_DECL_IMPORT
#endif

#endif // LIBOPENCV_GLOBAL_H
