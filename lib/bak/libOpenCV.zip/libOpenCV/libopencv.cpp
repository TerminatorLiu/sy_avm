include "libopencv.h"

LibOpenCV::LibOpenCV()
{
}
