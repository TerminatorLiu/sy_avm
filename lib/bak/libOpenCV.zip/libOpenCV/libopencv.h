#ifndef LIBOPENCV_H
#define LIBOPENCV_H

#include "libOpenCV_global.h"

class LIBOPENCV_EXPORT LibOpenCV
{
public:
    LibOpenCV();
};

#endif // LIBOPENCV_H
