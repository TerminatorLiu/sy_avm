/****************************************************************************
**
** Copyright (C) 2016 The Qt Company Ltd.
** Contact: https://www.qt.io/licensing/
**
** This file is part of the documentation of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** BSD License Usage
** Alternatively, you may use this file under the terms of the BSD license
** as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of The Qt Company Ltd nor the names of its
**     contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include "openglwindow.h"

#include <QtGui/QGuiApplication>
//#include <QtGui/QMatrix4x4>
//#include <QtGui/QOpenGLShaderProgram>
//#include <QtGui/QScreen>

//#include <QtCore/qmath.h>

#include <stdio.h>
#include <GLES3/gl3.h>
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include "opengl_common.h"

int steeringWheelAngle = 0;

extern int avmInit(safImgRect allView, safImgRect singleView);
extern void runRender(int viewMode, float steeringWheelAngle);

class TriangleWindow : public OpenGLWindow
{
public:
    TriangleWindow();

    void initialize() override;
    void render() override;

private:
    GLuint m_posAttr;
    GLuint m_colAttr;
    GLuint m_matrixUniform;

    GLuint m_program;
    int m_frame;
};

TriangleWindow::TriangleWindow()
    : m_program(0)
    , m_frame(0)
{
}
//! [1]

//! [2]
int main(int argc, char **argv)
{
    QGuiApplication app(argc, argv);

    QSurfaceFormat format;
    format.setSamples(16);

    TriangleWindow window;
    window.setFormat(format);
    window.resize(1280, 720);
    window.show();

    window.setAnimating(true);

    return app.exec();
}




void TriangleWindow::initialize()
{
	safImgRect allView, singleView;

    allView.width = 360;
	allView.height = 720;
	allView.x = 0;
	allView.y = 0;

    singleView.width = 920;//288;
	singleView.height = 720;
    singleView.x = 360;
	singleView.y = 0;


    avmInit(allView, singleView);
}

void BVSAutoChgAngleTest(void)
{
    static int step = 5;

    steeringWheelAngle += step;
    if(steeringWheelAngle >= 900)
    {
        step = -5;
    }
    else if(steeringWheelAngle <= -900)
    {
        step = 5;
    }
}

void TriangleWindow::render()
{
    const qreal retinaScale = devicePixelRatio();
	static unsigned int flag = 0;

	if(m_frame % 100 == 0)
	{
		flag++;
		//printf("flag = %d\n",flag);
	}
    glViewport(0, 0, width() * retinaScale, height() * retinaScale);
	//printf("%d %d %d\n",width(),height(),m_frame);
    glClear(GL_COLOR_BUFFER_BIT);

	BVSAutoChgAngleTest();

    runRender(VIEW_UNDISTORT_BACK, steeringWheelAngle / 23.6);

    ++m_frame;
}


