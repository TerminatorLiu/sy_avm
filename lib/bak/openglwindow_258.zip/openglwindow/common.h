typedef struct _safImgRect
{
    int x;       
    int y;       
    int width;    
    int height;   
} safImgRect;


#if 0
typedef enum _viewMode
{
	VIEW_FRONT = 0,
	VIEW_BACK_UP,
	VIEW_LEFT,
	VIEW_RIGHT,
	VIEW_BACK_DOWN,
	VIEW_FOUR_CAMERA
}viewMode;
#else
typedef enum _ViewState
{
    VIEW_OVERALL = 0,   //全景图（全景图+四个田字格）
    VIEW_LEFT,                   //左视图（点击左边按钮，左转向灯，左转方向盘）
    VIEW_RIGHT,                //右视图 （点击右边按钮，右转向灯，右转方向盘）
    VIEW_BACK,                  //后视图  （点击后面按钮）
    VIEW_FRONT,               //前视图 （点击前面视图按钮）
    VIEW_BACKWARD       //VIEW_BACK_DOWN
}ViewState;
#endif


typedef enum _carState
{
    EMPTY = 0,   //空载
    HEAVY       //满载
}carState;

